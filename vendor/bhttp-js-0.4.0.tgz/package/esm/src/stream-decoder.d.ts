/**
 * Streaming BHTTP decoder for incremental parsing.
 *
 * Accepts bytes incrementally via push(), yields events as they're parsed.
 * Supports both known-length (0/1) and indeterminate-length (2/3) messages.
 */
/**
 * Events emitted by the streaming decoder.
 */
export type BHttpEvent = BHttpRequestPreambleEvent | BHttpResponsePreambleEvent | BHttpInformationalEvent | BHttpContentEvent | BHttpTrailersEvent | BHttpEndEvent;
export interface BHttpRequestPreambleEvent {
    readonly type: "request-preamble";
    readonly method: string;
    readonly scheme: string;
    readonly authority: string;
    readonly path: string;
    readonly headers: Headers;
}
export interface BHttpResponsePreambleEvent {
    readonly type: "response-preamble";
    readonly status: number;
    readonly headers: Headers;
}
export interface BHttpInformationalEvent {
    readonly type: "informational";
    readonly status: number;
    readonly headers: Headers;
}
export interface BHttpContentEvent {
    readonly type: "content";
    readonly data: Uint8Array;
}
export interface BHttpTrailersEvent {
    readonly type: "trailers";
    readonly headers: Headers;
}
export interface BHttpEndEvent {
    readonly type: "end";
}
/**
 * Streaming BHTTP decoder.
 *
 * Usage:
 * ```ts
 * const decoder = new BHttpStreamDecoder();
 * for (const chunk of incomingData) {
 *   for (const event of decoder.push(chunk)) {
 *     switch (event.type) {
 *       case "request-preamble": // ...
 *       case "content": // ...
 *     }
 *   }
 * }
 * for (const event of decoder.end()) {
 *   // handle final events
 * }
 * ```
 */
export declare class BHttpStreamDecoder {
    private _buffer;
    private _offset;
    private _phase;
    private _isRequest;
    private _isKnownLength;
    private _method;
    private _scheme;
    private _authority;
    private _path;
    private _controlStep;
    private _status;
    private _knownSectionLen;
    private _knownSectionEnd;
    private _knownSectionLenRead;
    private _headers;
    private _pendingHeaderName;
    private _shouldContinueProcessing;
    /**
     * Push bytes into the decoder and get parsed events.
     *
     * @param data - Incoming bytes
     * @returns Array of parsed events (may be empty if more data needed)
     */
    push(data: Uint8Array): BHttpEvent[];
    /**
     * Signal end of input and get any remaining events.
     *
     * @returns Final events
     * @throws InvalidMessageError if message is incomplete
     */
    end(): BHttpEvent[];
    /**
     * Process current phase, returning event if complete.
     * Returns undefined if more data needed, null if phase complete but no event.
     */
    private _processPhase;
    private _processFraming;
    private _processRequestControl;
    private _processResponseStatus;
    private _processHeadersKnown;
    private _processHeadersIndeterminate;
    private _tryParseKnownLengthHeaders;
    private _tryParseIndeterminateLengthHeaders;
    private _emitPreambleEvent;
    private _processContentKnown;
    private _processContentIndeterminate;
    private _processTrailersKnown;
    private _processTrailersIndeterminate;
    /**
     * Try to decode a VLI-prefixed string. Returns undefined if not enough data.
     * Does NOT rollback offset on failure - caller must handle.
     */
    private _tryDecodeVliString;
}
//# sourceMappingURL=stream-decoder.d.ts.map