/**
 * Streaming BHTTP encoder for indeterminate-length messages.
 *
 * RFC 9292 Section 3.2: Indeterminate-Length Messages
 * - Framing indicator 2 = request, 3 = response
 * - Headers terminated by 0 (Name Length = 0)
 * - Content chunks: varint length + data, terminated by 0
 * - Trailers terminated by 0
 */
/**
 * Streaming encoder for BHTTP requests (indeterminate-length).
 *
 * Usage:
 * ```ts
 * const encoder = new BHttpRequestStreamEncoder();
 * yield encoder.encodePreamble("POST", "https", "example.com", "/api", headers);
 * yield encoder.encodeContentChunk(chunk1);
 * yield encoder.encodeContentChunk(chunk2);
 * yield encoder.encodeEnd();
 * ```
 */
export declare class BHttpRequestStreamEncoder {
    private _preambleEncoded;
    private _ended;
    /**
     * Encode request preamble: framing indicator + control data + headers.
     *
     * @param method - HTTP method (e.g., "GET", "POST")
     * @param scheme - URL scheme (e.g., "https")
     * @param authority - Host and optional port (e.g., "example.com:8080")
     * @param path - Request path with query (e.g., "/api?foo=bar")
     * @param headers - Request headers
     */
    encodePreamble(method: string, scheme: string, authority: string, path: string, headers: Headers): Uint8Array;
    /**
     * Encode a content chunk.
     *
     * @param data - Chunk data (must be non-empty)
     */
    encodeContentChunk(data: Uint8Array): Uint8Array;
    /**
     * Encode end: content terminator + trailers.
     *
     * @param trailers - Optional trailing headers
     */
    encodeEnd(trailers?: Headers): Uint8Array;
}
/**
 * Streaming encoder for BHTTP responses (indeterminate-length).
 *
 * Usage:
 * ```ts
 * const encoder = new BHttpResponseStreamEncoder();
 * yield encoder.encodePreamble(200, headers);
 * yield encoder.encodeContentChunk(chunk1);
 * yield encoder.encodeEnd();
 * ```
 */
export declare class BHttpResponseStreamEncoder {
    private _preambleEncoded;
    private _ended;
    /**
     * Encode response preamble: framing indicator + status + headers.
     *
     * @param status - HTTP status code (e.g., 200, 404)
     * @param headers - Response headers
     * @param informationalResponses - Optional 1xx informational responses
     */
    encodePreamble(status: number, headers: Headers, informationalResponses?: Array<{
        status: number;
        headers: Headers;
    }>): Uint8Array;
    /**
     * Encode a content chunk.
     *
     * @param data - Chunk data (must be non-empty)
     */
    encodeContentChunk(data: Uint8Array): Uint8Array;
    /**
     * Encode end: content terminator + trailers.
     *
     * @param trailers - Optional trailing headers
     */
    encodeEnd(trailers?: Headers): Uint8Array;
}
//# sourceMappingURL=stream-encoder.d.ts.map