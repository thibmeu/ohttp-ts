/**
 * Streaming BHTTP encoder for indeterminate-length messages.
 *
 * RFC 9292 Section 3.2: Indeterminate-Length Messages
 * - Framing indicator 2 = request, 3 = response
 * - Headers terminated by 0 (Name Length = 0)
 * - Content chunks: varint length + data, terminated by 0
 * - Trailers terminated by 0
 */
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./vli.js"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.BHttpResponseStreamEncoder = exports.BHttpRequestStreamEncoder = void 0;
    const vli_js_1 = require("./vli.js");
    const FRAMING_REQUEST_INDETERMINATE = 2;
    const FRAMING_RESPONSE_INDETERMINATE = 3;
    const textEncoder = new TextEncoder();
    /**
     * Encode a string with VLI length prefix.
     */
    function encodeVliString(s) {
        const bytes = textEncoder.encode(s);
        const lenVli = (0, vli_js_1.encodeVli)(bytes.length);
        const result = new Uint8Array(lenVli.length + bytes.length);
        result.set(lenVli);
        result.set(bytes, lenVli.length);
        return result;
    }
    /**
     * Encode headers as indeterminate-length field section.
     * Each field: Name Length (i), Name, Value Length (i), Value
     * Terminated by Name Length = 0
     */
    function encodeIndeterminateHeaders(headers) {
        const parts = [];
        let totalLen = 0;
        headers.forEach((value, name) => {
            const nameBytes = encodeVliString(name);
            const valueBytes = encodeVliString(value);
            parts.push(nameBytes, valueBytes);
            totalLen += nameBytes.length + valueBytes.length;
        });
        // Terminator: Name Length = 0
        const terminator = (0, vli_js_1.encodeVli)(0);
        totalLen += terminator.length;
        const result = new Uint8Array(totalLen);
        let offset = 0;
        for (const part of parts) {
            result.set(part, offset);
            offset += part.length;
        }
        result.set(terminator, offset);
        return result;
    }
    /**
     * Streaming encoder for BHTTP requests (indeterminate-length).
     *
     * Usage:
     * ```ts
     * const encoder = new BHttpRequestStreamEncoder();
     * yield encoder.encodePreamble("POST", "https", "example.com", "/api", headers);
     * yield encoder.encodeContentChunk(chunk1);
     * yield encoder.encodeContentChunk(chunk2);
     * yield encoder.encodeEnd();
     * ```
     */
    class BHttpRequestStreamEncoder {
        constructor() {
            Object.defineProperty(this, "_preambleEncoded", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
            Object.defineProperty(this, "_ended", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
        }
        /**
         * Encode request preamble: framing indicator + control data + headers.
         *
         * @param method - HTTP method (e.g., "GET", "POST")
         * @param scheme - URL scheme (e.g., "https")
         * @param authority - Host and optional port (e.g., "example.com:8080")
         * @param path - Request path with query (e.g., "/api?foo=bar")
         * @param headers - Request headers
         */
        encodePreamble(method, scheme, authority, path, headers) {
            if (this._preambleEncoded) {
                throw new Error("Preamble already encoded");
            }
            this._preambleEncoded = true;
            const parts = [];
            // Framing indicator
            parts.push((0, vli_js_1.encodeVli)(FRAMING_REQUEST_INDETERMINATE));
            // Request Control Data
            parts.push(encodeVliString(method));
            parts.push(encodeVliString(scheme));
            parts.push(encodeVliString(authority));
            parts.push(encodeVliString(path));
            // Headers (indeterminate-length)
            parts.push(encodeIndeterminateHeaders(headers));
            // Concatenate
            const totalLen = parts.reduce((sum, p) => sum + p.length, 0);
            const result = new Uint8Array(totalLen);
            let offset = 0;
            for (const part of parts) {
                result.set(part, offset);
                offset += part.length;
            }
            return result;
        }
        /**
         * Encode a content chunk.
         *
         * @param data - Chunk data (must be non-empty)
         */
        encodeContentChunk(data) {
            if (!this._preambleEncoded) {
                throw new Error("Preamble must be encoded first");
            }
            if (this._ended) {
                throw new Error("Encoding already ended");
            }
            if (data.length === 0) {
                throw new Error("Content chunk cannot be empty");
            }
            const lenVli = (0, vli_js_1.encodeVli)(data.length);
            const result = new Uint8Array(lenVli.length + data.length);
            result.set(lenVli);
            result.set(data, lenVli.length);
            return result;
        }
        /**
         * Encode end: content terminator + trailers.
         *
         * @param trailers - Optional trailing headers
         */
        encodeEnd(trailers) {
            if (!this._preambleEncoded) {
                throw new Error("Preamble must be encoded first");
            }
            if (this._ended) {
                throw new Error("Encoding already ended");
            }
            this._ended = true;
            const parts = [];
            // Content terminator: length = 0
            parts.push((0, vli_js_1.encodeVli)(0));
            // Trailers (indeterminate-length)
            if (trailers) {
                parts.push(encodeIndeterminateHeaders(trailers));
            }
            else {
                // Empty trailers: just terminator
                parts.push((0, vli_js_1.encodeVli)(0));
            }
            const totalLen = parts.reduce((sum, p) => sum + p.length, 0);
            const result = new Uint8Array(totalLen);
            let offset = 0;
            for (const part of parts) {
                result.set(part, offset);
                offset += part.length;
            }
            return result;
        }
    }
    exports.BHttpRequestStreamEncoder = BHttpRequestStreamEncoder;
    /**
     * Streaming encoder for BHTTP responses (indeterminate-length).
     *
     * Usage:
     * ```ts
     * const encoder = new BHttpResponseStreamEncoder();
     * yield encoder.encodePreamble(200, headers);
     * yield encoder.encodeContentChunk(chunk1);
     * yield encoder.encodeEnd();
     * ```
     */
    class BHttpResponseStreamEncoder {
        constructor() {
            Object.defineProperty(this, "_preambleEncoded", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
            Object.defineProperty(this, "_ended", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
        }
        /**
         * Encode response preamble: framing indicator + status + headers.
         *
         * @param status - HTTP status code (e.g., 200, 404)
         * @param headers - Response headers
         * @param informationalResponses - Optional 1xx informational responses
         */
        encodePreamble(status, headers, informationalResponses) {
            if (this._preambleEncoded) {
                throw new Error("Preamble already encoded");
            }
            if (status < 200 || status >= 600) {
                throw new Error("Final status must be 200-599");
            }
            this._preambleEncoded = true;
            const parts = [];
            // Framing indicator
            parts.push((0, vli_js_1.encodeVli)(FRAMING_RESPONSE_INDETERMINATE));
            // Informational responses (1xx)
            if (informationalResponses) {
                for (const ir of informationalResponses) {
                    if (ir.status < 100 || ir.status >= 200) {
                        throw new Error("Informational status must be 100-199");
                    }
                    parts.push((0, vli_js_1.encodeVli)(ir.status));
                    parts.push(encodeIndeterminateHeaders(ir.headers));
                }
            }
            // Final status
            parts.push((0, vli_js_1.encodeVli)(status));
            // Headers (indeterminate-length)
            parts.push(encodeIndeterminateHeaders(headers));
            // Concatenate
            const totalLen = parts.reduce((sum, p) => sum + p.length, 0);
            const result = new Uint8Array(totalLen);
            let offset = 0;
            for (const part of parts) {
                result.set(part, offset);
                offset += part.length;
            }
            return result;
        }
        /**
         * Encode a content chunk.
         *
         * @param data - Chunk data (must be non-empty)
         */
        encodeContentChunk(data) {
            if (!this._preambleEncoded) {
                throw new Error("Preamble must be encoded first");
            }
            if (this._ended) {
                throw new Error("Encoding already ended");
            }
            if (data.length === 0) {
                throw new Error("Content chunk cannot be empty");
            }
            const lenVli = (0, vli_js_1.encodeVli)(data.length);
            const result = new Uint8Array(lenVli.length + data.length);
            result.set(lenVli);
            result.set(data, lenVli.length);
            return result;
        }
        /**
         * Encode end: content terminator + trailers.
         *
         * @param trailers - Optional trailing headers
         */
        encodeEnd(trailers) {
            if (!this._preambleEncoded) {
                throw new Error("Preamble must be encoded first");
            }
            if (this._ended) {
                throw new Error("Encoding already ended");
            }
            this._ended = true;
            const parts = [];
            // Content terminator: length = 0
            parts.push((0, vli_js_1.encodeVli)(0));
            // Trailers (indeterminate-length)
            if (trailers) {
                parts.push(encodeIndeterminateHeaders(trailers));
            }
            else {
                // Empty trailers: just terminator
                parts.push((0, vli_js_1.encodeVli)(0));
            }
            const totalLen = parts.reduce((sum, p) => sum + p.length, 0);
            const result = new Uint8Array(totalLen);
            let offset = 0;
            for (const part of parts) {
                result.set(part, offset);
                offset += part.length;
            }
            return result;
        }
    }
    exports.BHttpResponseStreamEncoder = BHttpResponseStreamEncoder;
});
