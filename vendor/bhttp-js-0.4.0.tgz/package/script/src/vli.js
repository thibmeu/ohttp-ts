/**
 * Variable-Length Integer utilities for streaming decode.
 *
 * quicvarint throws on insufficient bytes; this module provides
 * decodeVli() which returns undefined instead (streaming-friendly).
 */
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "quicvarint"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.vliEncodedLength = exports.encodeVli = exports.MIN = exports.MAX = void 0;
    exports.vliExpectedLength = vliExpectedLength;
    exports.decodeVli = decodeVli;
    const quicvarint_1 = require("quicvarint");
    Object.defineProperty(exports, "MAX", { enumerable: true, get: function () { return quicvarint_1.MAX; } });
    Object.defineProperty(exports, "MIN", { enumerable: true, get: function () { return quicvarint_1.MIN; } });
    Object.defineProperty(exports, "encodeVli", { enumerable: true, get: function () { return quicvarint_1.encode; } });
    Object.defineProperty(exports, "vliEncodedLength", { enumerable: true, get: function () { return quicvarint_1.length; } });
    /**
     * Get expected byte length from VLI first byte.
     */
    function vliExpectedLength(firstByte) {
        const prefix = firstByte >> 6;
        return 1 << prefix; // 0->1, 1->2, 2->4, 3->8
    }
    /**
     * Decode a VLI from buffer at offset.
     *
     * Returns undefined if not enough bytes available (enables streaming).
     * Throws if value exceeds MAX.
     */
    function decodeVli(buf, offset) {
        if (offset >= buf.length) {
            return undefined;
        }
        const expectedLen = vliExpectedLength(buf[offset]);
        if (offset + expectedLen > buf.length) {
            return undefined;
        }
        const slice = buf.subarray(offset, offset + expectedLen);
        const result = (0, quicvarint_1.decode)(slice);
        return {
            value: result.value,
            bytesRead: result.usize,
        };
    }
});
