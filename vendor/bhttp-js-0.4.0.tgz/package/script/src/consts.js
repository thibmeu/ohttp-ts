(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.VLI_LEN_8 = exports.VLI_LEN_4 = exports.VLI_LEN_2 = exports.VLI_LEN_1 = exports.VLI_MASK_LSB = exports.VLI_MASK_VALUE = exports.VLI_MASK_HEADER = void 0;
    exports.VLI_MASK_HEADER = 0x3f; // 00111111
    exports.VLI_MASK_VALUE = 0xc0; // 11000000
    exports.VLI_MASK_LSB = 0xff; // 11111111
    exports.VLI_LEN_1 = 0x00; // 00000000
    exports.VLI_LEN_2 = 0x40; // 01000000
    exports.VLI_LEN_4 = 0x80; // 10000000
    exports.VLI_LEN_8 = 0xc0; // 11000000
});
