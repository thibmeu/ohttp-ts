(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.NotSupportedError = exports.InvalidMessageError = void 0;
    /**
     * The base error class of hpke-js.
     */
    class BHttpError extends Error {
    }
    /**
     * Invalid message.
     */
    class InvalidMessageError extends BHttpError {
    }
    exports.InvalidMessageError = InvalidMessageError;
    /**
     * Not supported data.
     */
    class NotSupportedError extends BHttpError {
    }
    exports.NotSupportedError = NotSupportedError;
});
