/**
 * Streaming BHTTP decoder for incremental parsing.
 *
 * Accepts bytes incrementally via push(), yields events as they're parsed.
 * Supports both known-length (0/1) and indeterminate-length (2/3) messages.
 */
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./errors.js", "./vli.js"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.BHttpStreamDecoder = void 0;
    const errors_js_1 = require("./errors.js");
    const vli_js_1 = require("./vli.js");
    // Framing indicators
    const FRAMING_REQUEST_KNOWN = 0;
    const FRAMING_RESPONSE_KNOWN = 1;
    const FRAMING_REQUEST_INDETERMINATE = 2;
    const FRAMING_RESPONSE_INDETERMINATE = 3;
    const textDecoder = new TextDecoder();
    /**
     * Streaming BHTTP decoder.
     *
     * Usage:
     * ```ts
     * const decoder = new BHttpStreamDecoder();
     * for (const chunk of incomingData) {
     *   for (const event of decoder.push(chunk)) {
     *     switch (event.type) {
     *       case "request-preamble": // ...
     *       case "content": // ...
     *     }
     *   }
     * }
     * for (const event of decoder.end()) {
     *   // handle final events
     * }
     * ```
     */
    class BHttpStreamDecoder {
        constructor() {
            Object.defineProperty(this, "_buffer", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: new Uint8Array(0)
            });
            Object.defineProperty(this, "_offset", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: 0
            });
            Object.defineProperty(this, "_phase", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: "framing"
            });
            // Message type determined from framing indicator
            Object.defineProperty(this, "_isRequest", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
            Object.defineProperty(this, "_isKnownLength", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
            // Request control data (accumulated across calls)
            Object.defineProperty(this, "_method", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: ""
            });
            Object.defineProperty(this, "_scheme", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: ""
            });
            Object.defineProperty(this, "_authority", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: ""
            });
            Object.defineProperty(this, "_path", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: ""
            });
            Object.defineProperty(this, "_controlStep", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: 0
            }); // 0=method, 1=scheme, 2=authority, 3=path
            // Response status
            Object.defineProperty(this, "_status", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: 0
            });
            // Known-length section tracking
            Object.defineProperty(this, "_knownSectionLen", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: 0
            });
            Object.defineProperty(this, "_knownSectionEnd", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: 0
            });
            Object.defineProperty(this, "_knownSectionLenRead", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: false
            });
            // Accumulated headers/trailers
            Object.defineProperty(this, "_headers", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: new Headers()
            });
            Object.defineProperty(this, "_pendingHeaderName", {
                enumerable: true,
                configurable: true,
                writable: true,
                value: null
            });
        }
        _shouldContinueProcessing() {
            return this._phase !== "done" && this._phase !== "padding";
        }
        /**
         * Push bytes into the decoder and get parsed events.
         *
         * @param data - Incoming bytes
         * @returns Array of parsed events (may be empty if more data needed)
         */
        push(data) {
            if (this._phase === "done") {
                throw new Error("Decoder already finished");
            }
            // Append to buffer
            if (data.length > 0) {
                const newBuf = new Uint8Array(this._buffer.length + data.length);
                newBuf.set(this._buffer);
                newBuf.set(data, this._buffer.length);
                this._buffer = newBuf;
            }
            const events = [];
            // Process as much as possible
            // Note: _processPhase() mutates _phase, so we re-check each iteration
            while (this._shouldContinueProcessing()) {
                const event = this._processPhase();
                if (event === undefined) {
                    break; // Need more data
                }
                if (event !== null) {
                    events.push(event);
                }
            }
            return events;
        }
        /**
         * Signal end of input and get any remaining events.
         *
         * @returns Final events
         * @throws InvalidMessageError if message is incomplete
         */
        end() {
            if (this._phase === "done") {
                return [];
            }
            // Check padding
            if (this._phase === "padding") {
                while (this._offset < this._buffer.length) {
                    if (this._buffer[this._offset] !== 0x00) {
                        throw new errors_js_1.InvalidMessageError("Invalid padding data");
                    }
                    this._offset++;
                }
                this._phase = "done";
                return [{ type: "end" }];
            }
            throw new errors_js_1.InvalidMessageError("Incomplete message");
        }
        /**
         * Process current phase, returning event if complete.
         * Returns undefined if more data needed, null if phase complete but no event.
         */
        _processPhase() {
            switch (this._phase) {
                case "framing":
                    return this._processFraming();
                case "request-control":
                    return this._processRequestControl();
                case "response-status":
                    return this._processResponseStatus();
                case "headers-known":
                    return this._processHeadersKnown();
                case "headers-indeterminate":
                    return this._processHeadersIndeterminate();
                case "content-known":
                    return this._processContentKnown();
                case "content-indeterminate":
                    return this._processContentIndeterminate();
                case "trailers-known":
                    return this._processTrailersKnown();
                case "trailers-indeterminate":
                    return this._processTrailersIndeterminate();
                default:
                    return undefined;
            }
        }
        _processFraming() {
            const result = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
            if (result === undefined)
                return undefined;
            const framing = result.value;
            this._offset += result.bytesRead;
            switch (framing) {
                case FRAMING_REQUEST_KNOWN:
                    this._isRequest = true;
                    this._isKnownLength = true;
                    this._phase = "request-control";
                    break;
                case FRAMING_RESPONSE_KNOWN:
                    this._isRequest = false;
                    this._isKnownLength = true;
                    this._phase = "response-status";
                    break;
                case FRAMING_REQUEST_INDETERMINATE:
                    this._isRequest = true;
                    this._isKnownLength = false;
                    this._phase = "request-control";
                    break;
                case FRAMING_RESPONSE_INDETERMINATE:
                    this._isRequest = false;
                    this._isKnownLength = false;
                    this._phase = "response-status";
                    break;
                default:
                    throw new errors_js_1.InvalidMessageError("Invalid framing indicator");
            }
            return null;
        }
        _processRequestControl() {
            // Process control data fields one at a time, saving state between calls
            while (this._controlStep < 4) {
                const saveOffset = this._offset;
                const str = this._tryDecodeVliString();
                if (str === undefined) {
                    this._offset = saveOffset;
                    return undefined;
                }
                switch (this._controlStep) {
                    case 0:
                        this._method = str;
                        break;
                    case 1:
                        this._scheme = str;
                        break;
                    case 2:
                        this._authority = str;
                        break;
                    case 3:
                        this._path = str;
                        break;
                }
                this._controlStep++;
            }
            // Move to headers
            this._headers = new Headers();
            this._phase = this._isKnownLength ? "headers-known" : "headers-indeterminate";
            return null;
        }
        _processResponseStatus() {
            const saveOffset = this._offset;
            const result = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
            if (result === undefined)
                return undefined;
            const status = result.value;
            this._offset += result.bytesRead;
            // Check for informational response (1xx)
            if (status >= 100 && status < 200) {
                this._headers = new Headers();
                // Try to parse headers for informational response
                const complete = this._isKnownLength
                    ? this._tryParseKnownLengthHeaders()
                    : this._tryParseIndeterminateLengthHeaders();
                if (!complete) {
                    // Rollback
                    this._offset = saveOffset;
                    this._headers = new Headers();
                    this._knownSectionLenRead = false;
                    this._pendingHeaderName = null;
                    return undefined;
                }
                const event = {
                    type: "informational",
                    status,
                    headers: this._headers,
                };
                this._headers = new Headers();
                this._knownSectionLenRead = false;
                return event;
            }
            // Final status
            if (status < 100 || status >= 600) {
                throw new errors_js_1.InvalidMessageError("Invalid status code");
            }
            this._status = status;
            this._headers = new Headers();
            this._phase = this._isKnownLength ? "headers-known" : "headers-indeterminate";
            return null;
        }
        _processHeadersKnown() {
            const saveOffset = this._offset;
            const saveHeaders = new Headers();
            this._headers.forEach((v, k) => saveHeaders.set(k, v));
            const complete = this._tryParseKnownLengthHeaders();
            if (!complete) {
                this._offset = saveOffset;
                this._headers = saveHeaders;
                return undefined;
            }
            const event = this._emitPreambleEvent();
            this._phase = "content-known";
            this._knownSectionLenRead = false;
            return event;
        }
        _processHeadersIndeterminate() {
            const saveOffset = this._offset;
            const saveHeaders = new Headers();
            this._headers.forEach((v, k) => saveHeaders.set(k, v));
            const savePendingName = this._pendingHeaderName;
            const complete = this._tryParseIndeterminateLengthHeaders();
            if (!complete) {
                this._offset = saveOffset;
                this._headers = saveHeaders;
                this._pendingHeaderName = savePendingName;
                return undefined;
            }
            const event = this._emitPreambleEvent();
            this._phase = "content-indeterminate";
            this._pendingHeaderName = null;
            return event;
        }
        _tryParseKnownLengthHeaders() {
            // Read the headers length if not yet read
            if (!this._knownSectionLenRead) {
                const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
                if (lenResult === undefined)
                    return false;
                this._knownSectionLen = lenResult.value;
                this._offset += lenResult.bytesRead;
                this._knownSectionEnd = this._offset + this._knownSectionLen;
                this._knownSectionLenRead = true;
            }
            // Check if we have all header bytes
            if (this._buffer.length < this._knownSectionEnd) {
                return false;
            }
            // Parse headers until we reach the end
            while (this._offset < this._knownSectionEnd) {
                const name = this._tryDecodeVliString();
                if (name === undefined)
                    return false;
                const value = this._tryDecodeVliString();
                if (value === undefined)
                    return false;
                if (this._isRequest &&
                    name.localeCompare("host", undefined, { sensitivity: "accent" }) === 0 &&
                    this._authority === "") {
                    this._authority = value;
                }
                this._headers.set(name, value);
            }
            return true;
        }
        _tryParseIndeterminateLengthHeaders() {
            // Headers terminated by Name Length = 0
            while (true) {
                // If we have a pending header name, try to get value
                if (this._pendingHeaderName !== null) {
                    const value = this._tryDecodeVliString();
                    if (value === undefined)
                        return false;
                    if (this._isRequest &&
                        this._pendingHeaderName.localeCompare("host", undefined, { sensitivity: "accent" }) ===
                            0 &&
                        this._authority === "") {
                        this._authority = value;
                    }
                    this._headers.set(this._pendingHeaderName, value);
                    this._pendingHeaderName = null;
                    continue;
                }
                // Try to read next name length (or terminator)
                const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
                if (lenResult === undefined)
                    return false;
                if (lenResult.value === 0) {
                    // Terminator
                    this._offset += lenResult.bytesRead;
                    return true;
                }
                // Read the name
                const name = this._tryDecodeVliString();
                if (name === undefined)
                    return false;
                // Save name and try to get value on next iteration
                this._pendingHeaderName = name;
            }
        }
        _emitPreambleEvent() {
            if (this._isRequest) {
                return {
                    type: "request-preamble",
                    method: this._method,
                    scheme: this._scheme,
                    authority: this._authority,
                    path: this._path,
                    headers: this._headers,
                };
            }
            return {
                type: "response-preamble",
                status: this._status,
                headers: this._headers,
            };
        }
        _processContentKnown() {
            // Read the content length if not yet read
            if (!this._knownSectionLenRead) {
                const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
                if (lenResult === undefined)
                    return undefined;
                this._knownSectionLen = lenResult.value;
                this._offset += lenResult.bytesRead;
                this._knownSectionEnd = this._offset + this._knownSectionLen;
                this._knownSectionLenRead = true;
                if (this._knownSectionLen === 0) {
                    this._phase = "trailers-known";
                    this._knownSectionLenRead = false;
                    return null;
                }
            }
            // Check if we have all content bytes
            if (this._buffer.length < this._knownSectionEnd) {
                return undefined;
            }
            // Emit content event
            const data = this._buffer.slice(this._offset, this._knownSectionEnd);
            this._offset = this._knownSectionEnd;
            this._phase = "trailers-known";
            this._knownSectionLenRead = false;
            return { type: "content", data };
        }
        _processContentIndeterminate() {
            const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
            if (lenResult === undefined)
                return undefined;
            if (lenResult.value === 0) {
                // Terminator - move to trailers
                this._offset += lenResult.bytesRead;
                this._phase = "trailers-indeterminate";
                return null;
            }
            const chunkLen = lenResult.value;
            const chunkStart = this._offset + lenResult.bytesRead;
            const chunkEnd = chunkStart + chunkLen;
            if (this._buffer.length < chunkEnd) {
                // Not enough data for full chunk
                return undefined;
            }
            this._offset = chunkEnd;
            const data = this._buffer.slice(chunkStart, chunkEnd);
            return { type: "content", data };
        }
        _processTrailersKnown() {
            const saveOffset = this._offset;
            // Read the trailers length if not yet read
            if (!this._knownSectionLenRead) {
                const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
                if (lenResult === undefined)
                    return undefined;
                this._knownSectionLen = lenResult.value;
                this._offset += lenResult.bytesRead;
                this._knownSectionEnd = this._offset + this._knownSectionLen;
                this._knownSectionLenRead = true;
                if (this._knownSectionLen === 0) {
                    this._phase = "padding";
                    this._knownSectionLenRead = false;
                    return null;
                }
            }
            // Check if we have all trailer bytes
            if (this._buffer.length < this._knownSectionEnd) {
                this._offset = saveOffset;
                this._knownSectionLenRead = false;
                return undefined;
            }
            // Parse trailers
            const trailers = new Headers();
            while (this._offset < this._knownSectionEnd) {
                const name = this._tryDecodeVliString();
                if (name === undefined) {
                    this._offset = saveOffset;
                    this._knownSectionLenRead = false;
                    return undefined;
                }
                const value = this._tryDecodeVliString();
                if (value === undefined) {
                    this._offset = saveOffset;
                    this._knownSectionLenRead = false;
                    return undefined;
                }
                trailers.set(name, value);
            }
            this._phase = "padding";
            this._knownSectionLenRead = false;
            return { type: "trailers", headers: trailers };
        }
        _processTrailersIndeterminate() {
            const saveOffset = this._offset;
            const trailers = new Headers();
            let hasTrailers = false;
            while (true) {
                const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
                if (lenResult === undefined) {
                    this._offset = saveOffset;
                    return undefined;
                }
                if (lenResult.value === 0) {
                    // Terminator
                    this._offset += lenResult.bytesRead;
                    break;
                }
                const name = this._tryDecodeVliString();
                if (name === undefined) {
                    this._offset = saveOffset;
                    return undefined;
                }
                const value = this._tryDecodeVliString();
                if (value === undefined) {
                    this._offset = saveOffset;
                    return undefined;
                }
                trailers.set(name, value);
                hasTrailers = true;
            }
            this._phase = "padding";
            // Only emit trailers event if there are any
            if (!hasTrailers) {
                return null;
            }
            return { type: "trailers", headers: trailers };
        }
        /**
         * Try to decode a VLI-prefixed string. Returns undefined if not enough data.
         * Does NOT rollback offset on failure - caller must handle.
         */
        _tryDecodeVliString() {
            const lenResult = (0, vli_js_1.decodeVli)(this._buffer, this._offset);
            if (lenResult === undefined)
                return undefined;
            const strLen = lenResult.value;
            const strStart = this._offset + lenResult.bytesRead;
            const strEnd = strStart + strLen;
            if (this._buffer.length < strEnd) {
                return undefined;
            }
            const str = textDecoder.decode(this._buffer.subarray(strStart, strEnd));
            this._offset = strEnd;
            return str;
        }
    }
    exports.BHttpStreamDecoder = BHttpStreamDecoder;
});
