var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports", "./src/decoder.js", "./src/encoder.js", "./src/errors.js", "./src/stream-encoder.js", "./src/stream-decoder.js", "./src/vli.js"], factory);
    }
})(function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.vliExpectedLength = exports.vliEncodedLength = exports.decodeVli = exports.encodeVli = exports.BHttpStreamDecoder = exports.BHttpResponseStreamEncoder = exports.BHttpRequestStreamEncoder = exports.BHttpEncoder = exports.BHttpDecoder = void 0;
    var decoder_js_1 = require("./src/decoder.js");
    Object.defineProperty(exports, "BHttpDecoder", { enumerable: true, get: function () { return decoder_js_1.BHttpDecoder; } });
    var encoder_js_1 = require("./src/encoder.js");
    Object.defineProperty(exports, "BHttpEncoder", { enumerable: true, get: function () { return encoder_js_1.BHttpEncoder; } });
    __exportStar(require("./src/errors.js"), exports);
    // Streaming API
    var stream_encoder_js_1 = require("./src/stream-encoder.js");
    Object.defineProperty(exports, "BHttpRequestStreamEncoder", { enumerable: true, get: function () { return stream_encoder_js_1.BHttpRequestStreamEncoder; } });
    Object.defineProperty(exports, "BHttpResponseStreamEncoder", { enumerable: true, get: function () { return stream_encoder_js_1.BHttpResponseStreamEncoder; } });
    var stream_decoder_js_1 = require("./src/stream-decoder.js");
    Object.defineProperty(exports, "BHttpStreamDecoder", { enumerable: true, get: function () { return stream_decoder_js_1.BHttpStreamDecoder; } });
    // VLI utilities (for advanced use)
    var vli_js_1 = require("./src/vli.js");
    Object.defineProperty(exports, "encodeVli", { enumerable: true, get: function () { return vli_js_1.encodeVli; } });
    Object.defineProperty(exports, "decodeVli", { enumerable: true, get: function () { return vli_js_1.decodeVli; } });
    Object.defineProperty(exports, "vliEncodedLength", { enumerable: true, get: function () { return vli_js_1.vliEncodedLength; } });
    Object.defineProperty(exports, "vliExpectedLength", { enumerable: true, get: function () { return vli_js_1.vliExpectedLength; } });
});
